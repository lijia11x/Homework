# -*- coding:utf-8 -*-
import requests
import logging

logger = logging.getLogger('mylogger')
logging.basicConfig(level=logging.INFO,format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')





def scrape_douban(url, headers, page):
    index = 1
    for i in range(page):
        response = requests.get(url.format(i * 20), headers=headers)
        logger.info(f'当前爬取第{i}页电影')
        for item in response.json():
            title = item['title']
            cover_url = item['cover_url']
            logger.info(f'当前爬取电影:{title}')
            logger.info(f'当前爬取电影封面地址:{cover_url}')

            with open('./static/{}_{}.jpg'.format(index, title), 'wb') as f:
                jpg_res = requests.get(url=item['cover_url'])
                f.write(jpg_res.content)
            index += 1


if __name__ == '__main__':
    url = 'https://movie.douban.com/j/chart/top_list?type=19&interval_id=100%3A90&action=&start={}&limit=20'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
        'Cookie': 'bid=8z8X2_PuxLQ; douban-fav-remind=1; _ga=GA1.1.271902701.1677637189; __gads=ID=d180af2df82d4092-223506cd3dda00f1:T=1677637188:RT=1690420070:S=ALNI_MaednKmZnBmdciG8Tq49bzUoRrOtA; __gpi=UID=00000bce5273ccba:T=1677637188:RT=1690420070:S=ALNI_MZYCTWJgRdmaP5idQgVb6KTwjjFPg; _ga_RXNMP372GL=GS1.1.1690420069.1.1.1690420657.60.0.0; ll="108296"; _pk_ref.100001.4cf6=%5B%22%22%2C%22%22%2C1693270378%2C%22https%3A%2F%2Fwww.baidu.com%2Flink%3Furl%3Dz5uFqYUEBmUSRw5X9Q0k8ruBcY1GOtjRPtzhDER2TpGXG9TK0ff0pwNNfnJaiUuc%26wd%3D%26eqid%3Db8111572000583610000000464ed4165%22%5D; _pk_id.100001.4cf6=79a9b3a7d2841148.1693270378.; _pk_ses.100001.4cf6=1; ap_v=0,6.0; __utma=30149280.271902701.1677637189.1681807237.1693270378.3; __utmb=30149280.0.10.1693270378; __utmc=30149280; __utmz=30149280.1693270378.3.3.utmcsr=baidu|utmccn=(organic)|utmcmd=organic; __utma=223695111.271902701.1677637189.1693270378.1693270378.1; __utmb=223695111.0.10.1693270378; __utmc=223695111; __utmz=223695111.1693270378.1.1.utmcsr=baidu|utmccn=(organic)|utmcmd=organic; _vwo_uuid_v2=DBC81A903092B5F57132C6A322D9D7697|9956092403fb3066712e38d03134e618; __yadk_uid=evFWqAxuCfhYKVgzNeIiytRvPUQpU6Sg; Hm_lvt_16a14f3002af32bf3a75dfe352478639=1693270443; Hm_lpvt_16a14f3002af32bf3a75dfe352478639=1693270443',
        'Refer': 'https://movie.douban.com/typerank?type_name=%E6%83%8A%E6%82%9A&type=19&interval_id=100:90&action='
    }
    scrape_douban(url, headers, 3)
